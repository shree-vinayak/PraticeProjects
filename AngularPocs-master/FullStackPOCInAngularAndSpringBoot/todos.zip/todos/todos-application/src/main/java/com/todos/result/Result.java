package com.todos.result;

public enum Result {
	SUCCESS, ERROR, EXCEPTION
}

